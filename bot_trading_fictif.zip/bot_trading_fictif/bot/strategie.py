"""Décideurs : « stratégie à règles » (par défaut) et interface pour une IA interchangeable.

Contrat commun : decider(contexte) -> Decision(action, instrument, quantite, justification).
Le contexte ne contient QUE ce qui est connu à l'instant de décision (bougies
clôturées, cotation courante, portefeuille). Aucune donnée future.

Le programme VÉRIFIE ensuite chaque décision (valider_decision) avant exécution
simulée : espèces suffisantes, minimums, quantité détenue, marché négociable,
pas de levier, pas de vente à découvert.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

from .portefeuille import (Instrument, Portefeuille, cout_achat_minimum, quantite_max_achetable,
                           respecte_minimums, simuler_achat, simuler_vente)
from .outils import arrondi_inf

ACTIONS = ("acheter", "vendre", "attendre")


@dataclass
class Decision:
    action: str
    instrument: str | None = None
    quantite: float | None = None
    justification: str = ""

    def dict(self) -> dict:
        return {"action": self.action, "instrument": self.instrument, "quantite": self.quantite,
                "justification": self.justification}


def moyenne(xs):
    return sum(xs) / len(xs) if xs else None


def empreinte_strategie(cfg: dict) -> str:
    base = {"decideur": cfg["decideur"], "strategie": cfg["strategie"],
            "instruments": sorted(i["id"] for i in cfg["instruments"] if i.get("actif", True)),
            "frais": {i["id"]: (i["frais_pct"], i["frais_fixes_eur"], i["glissement_pct"]) for i in cfg["instruments"]}}
    return hashlib.sha256(json.dumps(base, sort_keys=True).encode()).hexdigest()[:12]


class StrategieRegles:
    """Croisement de moyennes mobiles sur bougies 5 min clôturées, un seul actif détenu à la fois.

    - ACHETER : aucune position, moyenne courte > moyenne longue d'au moins `ecart_minimal_pct`,
      et la bougie précédente ne remplissait PAS cette condition (vrai croisement, pas un simple
      état). On prend l'actif négociable dont l'écart est le plus fort, avec TOUTES les espèces.
    - VENDRE : position détenue et (moyenne courte < moyenne longue) OU perte > stop_protection_pct
      par rapport au coût d'achat (frais inclus).
    - ATTENDRE sinon. Après une transaction, on attend `bougies_attente_apres_transaction` bougies.
    """
    nom = "stratégie à règles"

    def __init__(self, p: dict):
        self.c, self.l = int(p["moyenne_courte"]), int(p["moyenne_longue"])
        self.ecart = float(p["ecart_minimal_pct"])
        self.stop = float(p["stop_protection_pct"])
        self.attente = int(p["bougies_attente_apres_transaction"])
        self.version = p.get("version", "?")

    def _signal(self, closes: list[float]) -> tuple[float | None, float | None]:
        if len(closes) < self.l + 1:
            return None, None
        mc, ml = moyenne(closes[-self.c:]), moyenne(closes[-self.l:])
        mc_prec, ml_prec = moyenne(closes[-self.c - 1:-1]), moyenne(closes[-self.l - 1:-1])
        return (mc - ml) / ml * 100, (mc_prec - ml_prec) / ml_prec * 100

    def decider(self, ctx: dict) -> Decision:
        port: Portefeuille = ctx["portefeuille"]
        cot, bg, ins = ctx["cotations"], ctx["bougies"], ctx["instruments"]
        if ctx.get("bougies_depuis_transaction") is not None and ctx["bougies_depuis_transaction"] < self.attente:
            return Decision("attendre", justification=f"période de repos après transaction "
                            f"({ctx['bougies_depuis_transaction']}/{self.attente} bougies)")
        # Vente ?
        for iid, pos in port.positions.items():
            if iid not in cot or not cot[iid].negociable:
                continue
            closes = [b[4] for b in bg.get(iid, [])]
            ecart, _ = self._signal(closes)
            v = simuler_vente(ins[iid], cot[iid].bid, pos["quantite"])
            perte = (v["net"] - pos["cout_total"]) / pos["cout_total"] * 100
            if perte <= -self.stop:
                return Decision("vendre", iid, pos["quantite"],
                                f"stop de protection : {perte:.2f} % sous le coût d'achat (seuil −{self.stop} %)")
            if ecart is not None and ecart < 0:
                return Decision("vendre", iid, pos["quantite"],
                                f"MM{self.c} repassée sous MM{self.l} (écart {ecart:.2f} %) ; P&L latent {perte:+.2f} %")
            return Decision("attendre", justification=f"position {iid} conservée : MM{self.c} > MM{self.l}"
                            + (f" (écart {ecart:+.2f} %)" if ecart is not None else " (historique insuffisant)")
                            + f", P&L latent {perte:+.2f} %")
        if port.positions:
            return Decision("attendre", justification="position détenue mais marché non négociable pour l'instant")
        # Achat ?
        meilleur, meilleur_ecart, detail = None, 0.0, []
        for iid, c in cot.items():
            if not c.negociable or iid not in bg:
                continue
            closes = [b[4] for b in bg[iid]]
            ecart, ecart_prec = self._signal(closes)
            if ecart is None:
                detail.append(f"{iid} : historique insuffisant ({len(closes)} bougies)")
                continue
            detail.append(f"{iid} : écart MM {ecart:+.2f} % (précédent {ecart_prec:+.2f} %)")
            if ecart >= self.ecart and ecart_prec < self.ecart and ecart > meilleur_ecart:
                meilleur, meilleur_ecart = iid, ecart
        if meilleur is None:
            return Decision("attendre", justification="aucun croisement haussier confirmé — " + " ; ".join(detail)
                            if detail else "aucun marché négociable")
        q = quantite_max_achetable(ins[meilleur], cot[meilleur].ask, port.cash)
        return Decision("acheter", meilleur, q,
                        f"croisement haussier MM{self.c}/MM{self.l} sur {meilleur} (écart {meilleur_ecart:+.2f} %) — "
                        f"achat avec la totalité des espèces")


class DecideurIA:
    """Branchement d'un modèle externe (OpenAI, Anthropic, modèle local…) : fournir une fonction
    `appeler(prompt: str) -> str` qui renvoie du JSON {"action", "instrument", "quantite", "justification"}.
    Le modèle ne reçoit que le contexte de l'instant ; sa réponse est validée comme toute décision."""
    nom = "IA externe"

    def __init__(self, appeler, nom_modele: str = "modèle"):
        self.appeler = appeler
        self.nom = f"IA : {nom_modele}"

    @staticmethod
    def construire_prompt(ctx: dict) -> str:
        port = ctx["portefeuille"]
        resume = {
            "espèces_eur": round(port.cash, 4),
            "positions": port.positions,
            "cotations": {k: {"acheteur": c.bid, "vendeur": c.ask, "négociable": c.negociable, "motif": c.motif}
                          for k, c in ctx["cotations"].items()},
            "dernières_clôtures": {k: [b[4] for b in v[-30:]] for k, v in ctx["bougies"].items()},
            "frais": {k: {"pct": i.frais_pct, "fixes": i.frais_fixes_eur, "glissement_pct": i.glissement_pct,
                          "min_qte": i.ordre_min_quantite, "min_eur": i.ordre_min_eur} for k, i in ctx["instruments"].items()},
        }
        return ("Tu gères un portefeuille FICTIF. Réponds UNIQUEMENT en JSON : "
                '{"action": "acheter|vendre|attendre", "instrument": "...", "quantite": nombre, "justification": "..."}. '
                "Pas de levier, pas de vente à découvert. Contexte :\n" + json.dumps(resume, ensure_ascii=False))

    def decider(self, ctx: dict) -> Decision:
        try:
            brut = self.appeler(self.construire_prompt(ctx))
            d = json.loads(brut[brut.index("{"): brut.rindex("}") + 1])
            return Decision(str(d.get("action", "")).lower(), d.get("instrument"),
                            float(d["quantite"]) if d.get("quantite") is not None else None,
                            str(d.get("justification", ""))[:500])
        except Exception as e:  # réponse illisible => on attend, et on garde la trace
            return Decision("attendre", justification=f"réponse IA inexploitable ({e}) — attente par sécurité")


def valider_decision(d: Decision, port: Portefeuille, cot: dict, ins: dict) -> str:
    """Renvoie '' si la décision est exécutable, sinon le motif de refus."""
    if d.action not in ACTIONS:
        return f"action inconnue « {d.action} »"
    if d.action == "attendre":
        return ""
    if d.instrument not in ins or not ins[d.instrument].actif:
        return f"instrument inconnu ou inactif « {d.instrument} »"
    c = cot.get(d.instrument)
    if c is None or not c.negociable:
        return f"{d.instrument} non négociable ({c.motif if c else 'aucune cotation'})"
    i: Instrument = ins[d.instrument]
    if d.quantite is None or d.quantite <= 0:
        return "quantité absente ou nulle"
    q = arrondi_inf(d.quantite, i.decimales_quantite)
    if d.action == "acheter":
        if port.positions and d.instrument not in port.positions:
            return "un seul actif détenu à la fois dans cette version"
        a = simuler_achat(i, c.ask, q)
        if not respecte_minimums(i, q, a["brut"]):
            return (f"sous les minimums ({q} < {i.ordre_min_quantite} ou {a['brut']:.2f} € < {i.ordre_min_eur} €) ; "
                    f"plus petit achat possible ≈ {cout_achat_minimum(i, c.ask):.2f} € frais inclus")
        if a["total"] > port.cash + 1e-9:
            return f"espèces insuffisantes : {a['total']:.4f} € nécessaires (frais inclus), {port.cash:.4f} € disponibles — pas de levier"
        return ""
    pos = port.positions.get(d.instrument)
    if pos is None:
        return "aucune position à vendre — vente à découvert interdite"
    if q > pos["quantite"] + 1e-12:
        return f"quantité {q} supérieure à la position {pos['quantite']} — vente à découvert interdite"
    v = simuler_vente(i, c.bid, q)
    if not respecte_minimums(i, q, v["brut"]):
        return f"vente sous les minimums ({v['brut']:.2f} € < {i.ordre_min_eur} €)"
    if v["net"] <= 0:
        return "produit net de la vente nul ou négatif"
    return ""
