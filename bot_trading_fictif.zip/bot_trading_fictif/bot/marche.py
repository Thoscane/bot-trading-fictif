"""Collecte et CONTRÔLE QUALITÉ des données de marché.

Règle absolue : aucun cours n'est inventé. Si une donnée est manquante, ancienne
ou incohérente, l'instrument est marqué « non négociable », le problème est
journalisé, et aucune transaction simulée n'est faite dessus.

Tous les prix renvoyés sont en EUR (les actions US sont converties avec le taux
EUR/USD de la même source, bougie par bougie).
"""
from __future__ import annotations

from dataclasses import dataclass

from .outils import nyse_ouvert
from .sources import ErreurSource


@dataclass
class Cotation:
    instrument: str
    bid: float               # prix acheteur en EUR (prix auquel on VEND)
    ask: float               # prix vendeur en EUR (prix auquel on ACHÈTE)
    source: str
    heure_donnee: float      # horodatage de la donnée (pas de la réception)
    fourchette: str          # "observée" ou "estimée (…)"
    negociable: bool
    motif: str = ""
    derniere_bougie_ts: int | None = None


def verifier_achat_vente(bid: float, ask: float, ecart_max_pct: float) -> str:
    if not (bid > 0 and ask > 0):
        return f"prix nul ou négatif (acheteur {bid}, vendeur {ask})"
    if bid > ask:
        return f"prix acheteur {bid} supérieur au prix vendeur {ask}"
    ecart = (ask - bid) / ((ask + bid) / 2) * 100
    if ecart > ecart_max_pct:
        return f"écart acheteur/vendeur anormal ({ecart:.2f} % > {ecart_max_pct} %)"
    return ""


def verifier_bougies(bougies: list, maintenant: float, duree: int, fraicheur_max: float) -> str:
    if not bougies:
        return "aucune bougie clôturée disponible"
    precedent = None
    for b in bougies[-300:]:
        ts, o, h, l, c, _ = b
        if min(o, h, l, c) <= 0:
            return f"bougie avec prix nul ou négatif ({ts})"
        if l > min(o, c) + 1e-9 or h < max(o, c) - 1e-9:
            return f"bougie incohérente (haut/bas) à {ts}"
        if precedent is not None and ts <= precedent:
            return "bougies dans le désordre ou en double"
        precedent = ts
    age = maintenant - (bougies[-1][0] + duree)
    if age > fraicheur_max:
        return f"dernière bougie clôturée trop ancienne ({age / 60:.0f} min)"
    return ""


class Collecteur:
    def __init__(self, cfg: dict, instruments: dict, kraken, twelve, incident):
        self.cfg = cfg
        self.ctrl = cfg["controle_donnees"]
        self.instruments = instruments
        self.kraken = kraken
        self.twelve = twelve
        self.incident = incident
        self.P = cfg["intervalle_minutes"] * 60
        self._cache: dict[str, list] = {}       # bougies brutes (devise d'origine)
        self._cache_fx: list = []
        self._maj_actions: float = 0.0
        self._erreur_actions: str = ""

    # ------------------------------------------------------------------ public
    def collecter(self, maintenant: float) -> tuple[dict, dict]:
        cot, bg = {}, {}
        self._crypto(maintenant, cot, bg)
        self._actions(maintenant, cot, bg)
        return cot, bg

    # ------------------------------------------------------------- crypto
    def _crypto(self, now: float, cot: dict, bg: dict) -> None:
        insts = [i for i in self.instruments.values() if i.actif and i.source == "kraken"]
        if not insts or self.kraken is None:
            return
        try:
            srv = self.kraken.heure_serveur()
        except ErreurSource as e:
            self.incident("donnees", f"Kraken injoignable : {e} — transactions crypto suspendues")
            return
        bloque_global = ""
        if abs(srv - now) > self.ctrl["ecart_horloge_max_secondes"]:
            bloque_global = f"horloge locale décalée de {srv - now:+.0f} s par rapport à Kraken"
            self.incident("horloge", bloque_global + " — transactions crypto suspendues")
        try:
            statut = self.kraken.statut_systeme()
            if statut != "online":
                bloque_global = f"Kraken en statut « {statut} »"
                self.incident("marche", bloque_global + " — transactions crypto suspendues")
        except ErreurSource as e:
            bloque_global = "statut Kraken inconnu"
            self.incident("donnees", f"statut Kraken illisible : {e}")
        try:
            ticks = self.kraken.tickers({i.cle_source or i.symbole_source: i.symbole_source for i in insts})
        except ErreurSource as e:
            self.incident("donnees", f"prix Kraken indisponibles : {e} — transactions crypto suspendues")
            return
        for ins in insts:
            t = ticks.get(ins.symbole_source)
            if not t:
                self.incident("donnees", f"{ins.id} : prix absent de la réponse Kraken")
                continue
            pb = verifier_achat_vente(t["bid"], t["ask"], self.ctrl["ecart_max_achat_vente_pct"])
            if pb:
                self.incident("incoherence", f"{ins.id} : {pb} — prix rejeté, transactions suspendues")
                continue  # prix incohérent : on ne l'utilise même pas pour valoriser
            motif = bloque_global
            try:
                brutes = self.kraken.bougies(ins.symbole_source, ins.cle_source or ins.symbole_source,
                                             self.cfg["intervalle_minutes"])
                closes = [b for b in brutes if b[0] + self.P <= srv]
                pb_b = verifier_bougies(closes, srv, self.P, self.ctrl["fraicheur_max_bougie_secondes"])
                if not pb_b:
                    milieu = (t["bid"] + t["ask"]) / 2
                    dev = abs(milieu - closes[-1][4]) / closes[-1][4] * 100
                    if dev > self.ctrl["ecart_max_prix_vs_bougie_pct"]:
                        pb_b = f"prix actuel éloigné de {dev:.1f} % de la dernière clôture"
                if pb_b:
                    self.incident("donnees", f"{ins.id} : {pb_b} — transactions suspendues")
                    motif = motif or pb_b
                else:
                    bg[ins.id] = closes
            except ErreurSource as e:
                motif = motif or "bougies indisponibles"
                self.incident("donnees", f"{ins.id} : bougies Kraken indisponibles : {e}")
                closes = []
            cot[ins.id] = Cotation(ins.id, t["bid"], t["ask"], self.kraken.NOM, srv, "observée (Kraken)",
                                   negociable=not motif, motif=motif,
                                   derniere_bougie_ts=closes[-1][0] if closes else None)

    # ----------------------------------------------------------- actions
    def _actions(self, now: float, cot: dict, bg: dict) -> None:
        insts = [i for i in self.instruments.values() if i.actif and i.source == "twelvedata"]
        if not insts:
            return
        if self.twelve is None:
            return  # désactivées (clé absente) — signalé une fois au démarrage
        ouvert = nyse_ouvert(now)
        attendu = (int(now) // self.P) * self.P - self.P  # ouverture de la dernière bougie close
        derniere = min((self._cache[i.id][-1][0] if self._cache.get(i.id) else 0) for i in insts)
        a_rafraichir = (
            not self._maj_actions
            or (ouvert and derniere < attendu and now - self._maj_actions >= 55)
            or (not ouvert and now - self._maj_actions >= 3600)
        )
        if a_rafraichir:
            self._rafraichir_actions(insts, now)
        fx = [b for b in self._cache_fx if b[0] + self.P <= now]
        besoin_fx = any(i.devise == "USD" for i in insts)
        for ins in insts:
            brutes = [b for b in self._cache.get(ins.id, []) if b[0] + self.P <= now]
            if not brutes or (besoin_fx and ins.devise == "USD" and not fx):
                continue  # aucune donnée : aucun cours, aucune valorisation (rien n'est inventé)
            pb = verifier_bougies(brutes, now, self.P, self.ctrl["anciennete_max_valorisation_heures"] * 3600)
            if pb:
                self.incident("donnees", f"{ins.id} : {pb} — aucun cours utilisé")
                continue
            conv = self._convertir(brutes, fx) if ins.devise == "USD" else brutes
            dernier = conv[-1]
            age = now - (dernier[0] + self.P)
            age_fx = now - (fx[-1][0] + self.P) if (ins.devise == "USD" and fx) else 0
            if not ouvert:
                motif = "marché fermé (séance NYSE 15h30-22h00, heure de Paris)"
            elif age > self.ctrl["fraicheur_max_bougie_secondes"] or age_fx > self.ctrl["fraicheur_max_bougie_secondes"]:
                motif = f"données anciennes ({max(age, age_fx) / 60:.0f} min) — jour férié ou retard de la source ?"
                self.incident("donnees", f"{ins.id} : {motif} — transactions suspendues")
            else:
                motif = ""
            demi = ins.fourchette_estimee_pct / 200
            px = dernier[4]
            cot[ins.id] = Cotation(ins.id, px * (1 - demi), px * (1 + demi),
                                   f"{self.twelve.NOM} — bougies 5 min + EUR/USD",
                                   dernier[0] + self.P,
                                   f"estimée ±{ins.fourchette_estimee_pct / 2:.3f} % (non observée)",
                                   negociable=not motif, motif=motif, derniere_bougie_ts=dernier[0])
            if not motif:
                bg[ins.id] = conv
            else:
                bg.setdefault(ins.id, conv)  # utile au contexte, mais non négociable

    def _rafraichir_actions(self, insts: list, now: float) -> None:
        self._maj_actions = now
        try:
            if any(i.devise == "USD" for i in insts):
                self._cache_fx = self.twelve.bougies(self.cfg["twelvedata"]["symbole_change"],
                                                     self.cfg["intervalle_minutes"])
            for ins in insts:
                self._cache[ins.id] = self.twelve.bougies(ins.symbole_source, self.cfg["intervalle_minutes"])
            self._erreur_actions = ""
        except ErreurSource as e:
            self._erreur_actions = str(e)
            self.incident("donnees", f"actions/ETF : {e} — transactions actions suspendues")

    @staticmethod
    def _convertir(bougies: list, fx: list) -> list:
        """Convertit des bougies en USD vers l'EUR avec le dernier taux EUR/USD connu À CET INSTANT
        (jamais un taux futur)."""
        sortie, j, taux = [], 0, None
        for b in bougies:
            while j < len(fx) and fx[j][0] <= b[0]:
                taux = fx[j][4]
                j += 1
            if taux is None:
                continue  # pas de taux connu avant cette bougie : on l'ignore
            sortie.append((b[0], b[1] / taux, b[2] / taux, b[3] / taux, b[4] / taux, b[5]))
        return sortie
