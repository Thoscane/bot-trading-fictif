@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Bot de trading FICTIF - aucun ordre reel. Ctrl+C pour arreter.
python lancer.py demarrer
pause
