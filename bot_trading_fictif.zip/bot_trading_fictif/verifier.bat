@echo off
chcp 65001 >nul
cd /d "%~dp0"
python lancer.py verifier
echo.
echo Tests automatiques :
python -m unittest tests.test_bot
pause
